# You know the drill...

def question_1():
    # raise NotImplemented
    return 'b'

def question_2():
    # raise NotImplemented
    return 'b'

def question_3():
    # raise NotImplemented
    return 'b'

def question_4():
    # raise NotImplemented
    return 'a'
